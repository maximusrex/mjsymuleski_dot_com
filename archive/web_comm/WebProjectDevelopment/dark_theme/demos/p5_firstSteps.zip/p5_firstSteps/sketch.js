var myCanvas;

function setup() {
    myCanvas = createCanvas(800,400);//draw a canvas 800 pixels wide and 400 pixels high
    myCanvas.parent("canvas1");//attach that canvas to the container with the id canvas1
}

function draw() {
    background(255);
    fill('#f21d5d');
    ellipse(50, 50, 80, 80);

}