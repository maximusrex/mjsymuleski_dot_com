
let forecasts = [];

function setup(){
    var canvas = createCanvas(400,300);
    canvas.hide();
    //loadJSON and call the callback function gotData
    //this request URL is formatted for forecast?, for zip=27701,us in "imperial" units, and ends with my API Key
    loadJSON("https://api.openweathermap.org/data/2.5/forecast?zip=27701,us&units=imperial&APPID=ba2e504dd7871e48f816c0e459d77ac7", gotData);
}

function gotData(data) {
    //what does the data look like?
    console.log(data); 
    
}