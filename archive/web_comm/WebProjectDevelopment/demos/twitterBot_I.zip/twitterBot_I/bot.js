//Setting up a bot.js application.
//first, we have to require the Twit package we installed

// Using the Twit node package
// https://github.com/ttezel/twit
var Twit = require('twit');

var consumerKey = "kdOUqEkygKZrhpdVQy5eqAQB7";
var consumerSecret = "h4dld0DEgiKhVCLIQEZfKxkASN9NO4bC74vG8pxLsNtMpKuVCh";

var token = "805832107973033984-3eLu9tqVI84fa3rv9rzHT85QISU47lW";
var tokenSecret = "AoQHgJTSVeMl5ReZYU8gQVDTreEmckWvCQhow87ODQWQ1";

//make a new twit object with consumer keys
var T = new Twit({
  consumer_key:         consumerKey,
  consumer_secret:      consumerSecret,
  access_token:         token,
  access_token_secret:  tokenSecret,
  timeout_ms:           60*1000,  // optional HTTP request timeout to apply to all requests.
  strictSSL:            true,     // optional - requires SSL certificates to be valid.
});

//require fs to save the file see node fs: https://www.w3schools.com/nodejs/nodejs_filesystem.asp
var fs = require('fs');

// Start the tweeter once
tweeter();

// Once every N milliseconds
setInterval(tweeter, 60*5*1000);

// Here is the bot!
function tweeter() {

  // get the tweets every n milliseconds
  T.get('search/tweets', { q: 'banana since:2011-07-11', count: 10 }, function(err, data, response) {
  console.log(data);
      var json = JSON.stringify(data);
      fs.writeFile('tweets.json', json, function(err){
          if(err){
              console.log(err);
          } else {
              console.log('tweets saved!');
          }
      })
  });

}


