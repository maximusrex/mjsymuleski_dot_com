//loading tweets with codebird
//first enter user consumer key  / token, etc for twitter
var consumerKey = "kdOUqEkygKZrhpdVQy5eqAQB7";
var consumerSecret = "h4dld0DEgiKhVCLIQEZfKxkASN9NO4bC74vG8pxLsNtMpKuVCh";

var token = "805832107973033984-3eLu9tqVI84fa3rv9rzHT85QISU47lW";
var tokenSecret = "AoQHgJTSVeMl5ReZYU8gQVDTreEmckWvCQhow87ODQWQ1";

var button;

let tweets = [];

//create a new Codebird object
var cb = new Codebird();

function setup() {
    //createCanvas(800, 600);
    //background(250);
    cb.setConsumerKey(consumerKey, consumerSecret);
    cb.setToken(token, tokenSecret);
    
    
    //stroke(0);
    //fill(255,100,100);
    ellipseMode(CENTER);
    button = createButton('Get Some Tweets');
    button.position(200,200);
    button.mousePressed(getTweets);
}

function getTweets() {
    
    tweets = [];//reset tweets to an empty array
    
    const params = {
        //what parameters for the search
        q: 'NYC', //how could you get user data into this query string
        result_type: 'recent',
        count: 20
    };
    
    //search tweets
/*    cb.__call('search_tweets', params, function(reply){
        createP('we got your tweets!').parent('replies');
        //console.log(reply.statuses[0]);//
        
        for(var i=0;i<reply.statuses.length;i++){
            //get just the tweets
            //var tweet = reply.statuses[i].text;
            //tweets.push(tweet);
            
            //or get an array of objects
            var tweet = {};
            tweet.user = reply.statuses[i].user.screen_name;
            tweet.text = reply.statuses[i].text;
            tweets.push(tweet);
            //console.log(tweet);
            
            //or create P for each of the tweets
            var newTweet = createP(tweet.user + ': ' + tweet.text);
            newTweet.style('font-family:monospace; background-color:#FF0000; color:#FFFFFF; font-size:18pt; padding:10px;')
            newTweet.parent('replies'); //add a new p to the parent container
            
            //how might you remove all of these, next time around?
        }
        
        console.log(tweets);
    });*/
    
    //or post a tweet using statuses_update
    cb.__call("statuses_update", {status: "I tweeted from p5!" }, function(reply,rate,err){
        //if there's an error what is it?
        if(err){
            console.log(err);
        }
        
        if(reply){
            console.log(reply);
        }
    });
}//end getTweets



