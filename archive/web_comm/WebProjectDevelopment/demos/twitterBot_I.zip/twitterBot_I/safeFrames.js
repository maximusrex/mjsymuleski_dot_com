//save canvase frames in base64 encoding

var img;


function setup(){
    createCanvas(400,400)
    background(255);
    stroke('#000')
    text('hit enter to save the canvas', 20, 20);
  
}

function mouseDragged(){
    strokeWeight(12);
    stroke(255,15,15);
    line(mouseX,mouseY,pmouseX,pmouseY);
}

function keyPressed() {
    if (keyCode === ENTER){
        saveFrames('out', 'png', 1, 25, gotData);
    }
}

function gotData(data){

    //frames are just here.  We can console.log them but need a server to save
    console.log(data[0].imageData);
    
    var rawImage = data[0].imageData;
    //var imgStringArray = rawImage.split(',');
    
    //append image to the page
    createImg(rawImage,success);
    //img = loadImage(rawImage,gotImage);
    
    
           
}//end gotData

function success(){
    console.log('it worked!');
}
